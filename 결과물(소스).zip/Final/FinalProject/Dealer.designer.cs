﻿namespace FinalProject
{
    partial class Dealer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblCarName = new System.Windows.Forms.Label();
            this.txtCar = new System.Windows.Forms.TextBox();
            this.btnREGISTER = new System.Windows.Forms.Button();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblKm = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblDealer = new System.Windows.Forms.Label();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtKm = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtDealer = new System.Windows.Forms.TextBox();
            this.lVFile = new System.Windows.Forms.ListView();
            this.carcode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.carkinds = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.carname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.caryear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.carkilo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.carprice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cardeal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.celling = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnCHANGE = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.lblKind = new System.Windows.Forms.Label();
            this.txtKind = new System.Windows.Forms.TextBox();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.lblCode = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCarName
            // 
            this.lblCarName.AutoSize = true;
            this.lblCarName.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.lblCarName.Location = new System.Drawing.Point(36, 157);
            this.lblCarName.Name = "lblCarName";
            this.lblCarName.Size = new System.Drawing.Size(31, 15);
            this.lblCarName.TabIndex = 0;
            this.lblCarName.Text = "모델";
            // 
            // txtCar
            // 
            this.txtCar.Location = new System.Drawing.Point(99, 154);
            this.txtCar.Name = "txtCar";
            this.txtCar.Size = new System.Drawing.Size(100, 21);
            this.txtCar.TabIndex = 1;
            // 
            // btnREGISTER
            // 
            this.btnREGISTER.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnREGISTER.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnREGISTER.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnREGISTER.ForeColor = System.Drawing.Color.White;
            this.btnREGISTER.Location = new System.Drawing.Point(39, 341);
            this.btnREGISTER.Name = "btnREGISTER";
            this.btnREGISTER.Size = new System.Drawing.Size(160, 53);
            this.btnREGISTER.TabIndex = 2;
            this.btnREGISTER.Text = "차량등록";
            this.btnREGISTER.UseVisualStyleBackColor = false;
            this.btnREGISTER.Click += new System.EventHandler(this.btnREGISTER_Click);
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.lblYear.Location = new System.Drawing.Point(36, 189);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(31, 15);
            this.lblYear.TabIndex = 4;
            this.lblYear.Text = "연식";
            // 
            // lblKm
            // 
            this.lblKm.AutoSize = true;
            this.lblKm.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.lblKm.Location = new System.Drawing.Point(36, 222);
            this.lblKm.Name = "lblKm";
            this.lblKm.Size = new System.Drawing.Size(55, 15);
            this.lblKm.TabIndex = 5;
            this.lblKm.Text = "주행거리";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.lblPrice.Location = new System.Drawing.Point(36, 254);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 15);
            this.lblPrice.TabIndex = 6;
            this.lblPrice.Text = "가격";
            // 
            // lblDealer
            // 
            this.lblDealer.AutoSize = true;
            this.lblDealer.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.lblDealer.Location = new System.Drawing.Point(36, 287);
            this.lblDealer.Name = "lblDealer";
            this.lblDealer.Size = new System.Drawing.Size(31, 15);
            this.lblDealer.TabIndex = 7;
            this.lblDealer.Text = "딜러";
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(99, 186);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(100, 21);
            this.txtYear.TabIndex = 8;
            // 
            // txtKm
            // 
            this.txtKm.Location = new System.Drawing.Point(99, 219);
            this.txtKm.Name = "txtKm";
            this.txtKm.Size = new System.Drawing.Size(100, 21);
            this.txtKm.TabIndex = 9;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(99, 251);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(100, 21);
            this.txtPrice.TabIndex = 10;
            // 
            // txtDealer
            // 
            this.txtDealer.Location = new System.Drawing.Point(99, 284);
            this.txtDealer.Name = "txtDealer";
            this.txtDealer.Size = new System.Drawing.Size(100, 21);
            this.txtDealer.TabIndex = 11;
            // 
            // lVFile
            // 
            this.lVFile.BackColor = System.Drawing.Color.White;
            this.lVFile.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.carcode,
            this.carkinds,
            this.carname,
            this.caryear,
            this.carkilo,
            this.carprice,
            this.cardeal,
            this.celling});
            this.lVFile.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lVFile.ForeColor = System.Drawing.Color.Black;
            this.lVFile.FullRowSelect = true;
            this.lVFile.GridLines = true;
            this.lVFile.Location = new System.Drawing.Point(222, 88);
            this.lVFile.Name = "lVFile";
            this.lVFile.Size = new System.Drawing.Size(949, 359);
            this.lVFile.TabIndex = 12;
            this.lVFile.UseCompatibleStateImageBehavior = false;
            this.lVFile.View = System.Windows.Forms.View.Details;
            this.lVFile.SelectedIndexChanged += new System.EventHandler(this.lVFile_SelectedIndexChanged);
            // 
            // carcode
            // 
            this.carcode.Text = "차량코드";
            this.carcode.Width = 110;
            // 
            // carkinds
            // 
            this.carkinds.Text = "차량종류";
            this.carkinds.Width = 110;
            // 
            // carname
            // 
            this.carname.Text = "모델";
            this.carname.Width = 200;
            // 
            // caryear
            // 
            this.caryear.Text = "연식(년도)";
            this.caryear.Width = 114;
            // 
            // carkilo
            // 
            this.carkilo.Text = "주행거리(Km)";
            this.carkilo.Width = 99;
            // 
            // carprice
            // 
            this.carprice.Text = "가격(만원)";
            this.carprice.Width = 85;
            // 
            // cardeal
            // 
            this.cardeal.Text = "딜러";
            this.cardeal.Width = 55;
            // 
            // celling
            // 
            this.celling.Text = "판매여부";
            this.celling.Width = 100;
            // 
            // btnCHANGE
            // 
            this.btnCHANGE.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnCHANGE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCHANGE.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnCHANGE.ForeColor = System.Drawing.Color.White;
            this.btnCHANGE.Location = new System.Drawing.Point(39, 409);
            this.btnCHANGE.Name = "btnCHANGE";
            this.btnCHANGE.Size = new System.Drawing.Size(74, 38);
            this.btnCHANGE.TabIndex = 13;
            this.btnCHANGE.Text = "수 정";
            this.btnCHANGE.UseVisualStyleBackColor = false;
            this.btnCHANGE.Click += new System.EventHandler(this.btnCHANGE_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(125, 409);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 38);
            this.button2.TabIndex = 14;
            this.button2.Text = "삭 제";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("휴먼엑스포", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(430, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(510, 41);
            this.label1.TabIndex = 16;
            this.label1.Text = "<  HEYYO!딜러 매물관리  >";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // lblKind
            // 
            this.lblKind.AutoSize = true;
            this.lblKind.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.lblKind.Location = new System.Drawing.Point(36, 126);
            this.lblKind.Name = "lblKind";
            this.lblKind.Size = new System.Drawing.Size(55, 15);
            this.lblKind.TabIndex = 17;
            this.lblKind.Text = "차량종류";
            // 
            // txtKind
            // 
            this.txtKind.Location = new System.Drawing.Point(99, 122);
            this.txtKind.Name = "txtKind";
            this.txtKind.Size = new System.Drawing.Size(100, 21);
            this.txtKind.TabIndex = 18;
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(99, 88);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(100, 21);
            this.txtCode.TabIndex = 19;
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.lblCode.Location = new System.Drawing.Point(37, 91);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(55, 15);
            this.lblCode.TabIndex = 20;
            this.lblCode.Text = "차량코드";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "로그아웃";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Dealer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1223, 481);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblCode);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.txtKind);
            this.Controls.Add(this.lblKind);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnCHANGE);
            this.Controls.Add(this.lVFile);
            this.Controls.Add(this.txtDealer);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtKm);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.lblDealer);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblKm);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.btnREGISTER);
            this.Controls.Add(this.txtCar);
            this.Controls.Add(this.lblCarName);
            this.Name = "Dealer";
            this.Text = "차량관리";
            this.TransparencyKey = System.Drawing.Color.MintCream;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCarName;
        private System.Windows.Forms.TextBox txtCar;
        private System.Windows.Forms.Button btnREGISTER;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblKm;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblDealer;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtKm;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtDealer;
        private System.Windows.Forms.ListView lVFile;
        private System.Windows.Forms.ColumnHeader carname;
        private System.Windows.Forms.ColumnHeader caryear;
        private System.Windows.Forms.ColumnHeader carkilo;
        private System.Windows.Forms.ColumnHeader carprice;
        private System.Windows.Forms.ColumnHeader cardeal;
        private System.Windows.Forms.Button btnCHANGE;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ColumnHeader carcode;
        private System.Windows.Forms.ColumnHeader carkinds;
        private System.Windows.Forms.ColumnHeader celling;
        private System.Windows.Forms.Label lblKind;
        private System.Windows.Forms.TextBox txtKind;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Button button1;
    }
}