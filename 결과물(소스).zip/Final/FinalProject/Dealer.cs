﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;


namespace FinalProject
{
    public partial class Dealer : Form
    {
        LoginForm login;
        VO vo = new VO();

        public Dealer(LoginForm loginForm)
        {
            InitializeComponent();
            login = loginForm;
            login.Hide();
        }


     
        static string StrSQL = string.Format("server=localhost;" +
                "user=root;" +
                "password=apmsetup;" +
                "database=Usedcar;" +
                "CharSet = utf8;");

        private string Data_Num;
        private string Data_Celling;

        MySqlConnection Conn = new MySqlConnection(StrSQL);

        private void Form2_Load(object sender, EventArgs e)
        {
            lVFile_MysqlClient_View();
        }

        private void lVFile_MysqlClient_View()
        {
            this.lVFile.Items.Clear();
            
           
            try
            {
                Conn.Open();
                if (Conn.State == ConnectionState.Open)
                {
                    var Comm = new MySqlCommand("select * from car", Conn);
                    var myRead = Comm.ExecuteReader();
                    while (myRead.Read())
                    {
                        var strArray = new String[] {myRead["차량코드"].ToString(),
                myRead["차량종류"].ToString(),myRead["모델"].ToString(),myRead["연식"].ToString(),myRead["주행거리"].ToString(),myRead["금액"].ToString(),
                myRead["딜러"].ToString(),myRead["판매여부"].ToString() };
                        var lvt = new ListViewItem(strArray);
                        this.lVFile.Items.Add(lvt);
                    }
                    myRead.Close();
                }

            }
            catch(Exception ex)
            {
                Conn.Close();
            }
            finally
            {
                Conn.Close();
                
            }

            


        }

        private void btnREGISTER_Click(object sender, EventArgs e)
        {
            if (this.txtCode.Text != "" && this.txtKind.Text != "" && this.txtCar.Text != "" &&
           this.txtYear.Text != "" && this.txtPrice.Text != "" && this.txtKm.Text != "" && this.txtDealer.Text != "")
            {
                try
                {
                    Conn.Open();
                    if (Conn.State == ConnectionState.Open)
                    {
                        string Sql = "insert into car " +
                            "values('" + this.txtCode.Text + "','" + this.txtKind.Text + "','" + this.txtCar.Text + "'," + this.txtYear.Text + "," + this.txtKm.Text + "," + this.txtPrice.Text + ",'" + this.txtDealer.Text + "','" + vo.Selling + "','" + vo.Consult + "')";
                        MySqlCommand Comm = new MySqlCommand(Sql, Conn);
                        int i = Comm.ExecuteNonQuery();

                        if (i == 1)
                        {
                            MessageBox.Show("정상적으로 저장되었습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);


                        }
                        else
                        {
                            MessageBox.Show("정상적으로 저장되지 않았습니다.", "에러", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Conn.Close();
                }
                finally
                {
                    Conn.Close();
                }
                Control_Clear();
                lVFile_MysqlClient_View();
            }
            else
            {
                MessageBox.Show("모두 입력하세요");
            }
        }

        private void Control_Clear()
        {
            this.txtCode.Clear();
            this.txtKind.Clear();
            this.txtCar.Clear();
            this.txtYear.Clear();
            this.txtPrice.Clear();
            this.txtKm.Clear();
            this.txtDealer.Clear();
        }
        private void btnSEARCH_Click(object sender, EventArgs e)
        {

        }

        private void btnCHANGE_Click(object sender, EventArgs e)
        {
            if (this.txtCode.Text != "" && this.txtKind.Text != "" && this.txtCar.Text != "" &&
                this.txtYear.Text != "" && this.txtPrice.Text != "" && this.txtKm.Text != "" && this.txtDealer.Text != "")
            {
                try
                {
                    Conn.Open();
                    if (Conn.State == ConnectionState.Open)
                    {
                        string update = "update car set 차량코드 = '" + this.txtCode.Text + "', 차량종류 = '" + this.txtKind.Text + "', 모델 = '" + this.txtCar.Text +
                            "', 연식 = "+this.txtYear.Text + ", 주행거리 = " + this.txtKm.Text + ", 금액 = " + this.txtPrice.Text + ", 딜러 = '" + this.txtDealer.Text + "' where 차량코드 = '" + this.txtCode.Text + "'";
                        MySqlCommand comm = new MySqlCommand(update, Conn);
                        comm.ExecuteNonQuery();

                    }
                }
                catch (Exception ex)
                {

                    System.Windows.Forms.MessageBox.Show("연결실패", ex.Message);
                    Conn.Close();

                }
                finally
                {
                    Conn.Close();
                }

                Control_Clear();
                lVFile_MysqlClient_View();
            }
            else
            {
                MessageBox.Show("모두 입력하세요"); 
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.lVFile.SelectedItems.Count > 0)
            {
                DialogResult dlr = MessageBox.Show("데이터를 삭제할까요?", "알림", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlr == DialogResult.Yes)
                {
                    var Conn = new MySqlConnection(StrSQL);
                    Conn.Open();
                    string Sql = "DELETE FROM car WHERE 차량코드 ='" + this.lVFile.SelectedItems[0].SubItems[0].Text+ "'";
                    var Comm = new MySqlCommand(Sql, Conn);
                    int i = Comm.ExecuteNonQuery();
                    if (i == 1)
                        MessageBox.Show("데이터가 정상적으로 삭제되었습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("데이터를 삭제하지 못하였습니다..", "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Control_Clear();
                    lVFile_MysqlClient_View();
                }
            }
            else
                MessageBox.Show("삭제할 행을 선택하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void lVFile_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(this.lVFile.SelectedItems.Count > 0)
            {
                this.txtKind.Text = this.lVFile.SelectedItems[0].SubItems[1].Text;
                this.txtCar.Text = this.lVFile.SelectedItems[0].SubItems[2].Text;
                this.txtYear.Text = this.lVFile.SelectedItems[0].SubItems[3].Text;
                this.txtKm.Text = this.lVFile.SelectedItems[0].SubItems[4].Text;
                this.txtPrice.Text = this.lVFile.SelectedItems[0].SubItems[5].Text;
                this.txtDealer.Text = this.lVFile.SelectedItems[0].SubItems[6].Text;
                this.txtCode.Text = this.lVFile.SelectedItems[0].SubItems[0].Text;
                Data_Celling = this.lVFile.SelectedItems[0].SubItems[7].Text;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            login.Show();
            this.Close();
        }
    }
}
