﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Threading;

namespace FinalProject
{
    class DAO
    {
        static string connStr = string.Format("server=localhost;" +
                "user=root;" +
                "password=apmsetup;" +
                "database=Usedcar;" +
                "CharSet = utf8;");

        MySqlConnection conn = new MySqlConnection(connStr);



        public void idpwCheck(VO vo, LoginForm loginForm)
        {
            
                try
                {
                    conn.Open();
                    if (conn.State == ConnectionState.Open)
                    {
                        string select = "select * from login where id = '" + vo.Id + "' and pw = '" + vo.Pw + "' and du = '" + vo.Du + "'";
                        MySqlCommand comm = new MySqlCommand(select, conn);
                        MySqlDataReader rdr = comm.ExecuteReader();
                        if (rdr.Read())
                        {
                            
                            if (vo.Du == vo.de)
                            {

                                Dealer deal = new Dealer(loginForm);
                                deal.Show();
                                loginForm.Visible = false;

                            }
                            else if (vo.Du == vo.us)
                            {
                                Buyer buy = new Buyer(loginForm);
                                buy.Show();
                                loginForm.Visible = false;

                            }

                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("로그인 정보 확인");

                        }

                        rdr.Close();
                    }
                }
                catch (Exception ex)
                {
                    
                    System.Windows.Forms.MessageBox.Show("연결실패", ex.Message);
                    conn.Close();

                }
            finally
            {
                conn.Close();
            }



        }


        public void findID(VO vo)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string select = "select * from login where name = '" + vo.Name + "'";
                    MySqlCommand comm = new MySqlCommand(select, conn);
                    MySqlDataReader rdr = comm.ExecuteReader();
                    if (rdr.Read())
                    {

                        System.Windows.Forms.MessageBox.Show("아이디는 " + rdr["id"].ToString() + "입니다.");
                        vo.Id = rdr["id"].ToString();
                        rdr.Close();
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("아이디가 없습니다.");
                    }
                }
            }
            catch (Exception ex)
            {

                System.Windows.Forms.MessageBox.Show("연결실패", ex.Message);
                conn.Close();

            }
            finally
            {
                conn.Close();
            }
        }

        public void findPW(VO vo)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string select = "select * from login where id = '" + vo.Id + "' and name = '" + vo.Name +"'";
                    MySqlCommand comm = new MySqlCommand(select, conn);
                    MySqlDataReader rdr = comm.ExecuteReader();
                    if (rdr.Read())
                    {

                        System.Windows.Forms.MessageBox.Show("비밀번호는 " + rdr["pw"].ToString() + "입니다.");
                        vo.Pw = rdr["pw"].ToString();
                        rdr.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                System.Windows.Forms.MessageBox.Show("연결실패", ex.Message);
                conn.Close();

            }
            finally
            {
                conn.Close();
            }
        }

        public void join(VO vo, join joins)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string select = "select * from login where name = '" + vo.Name + "'";
                    MySqlCommand commm = new MySqlCommand(select, conn);
                    MySqlDataReader rdr = commm.ExecuteReader();
                    if (rdr.Read())
                    {
                        System.Windows.Forms.MessageBox.Show("이미 가입한 아이디가 있습니다");
                        rdr.Close();
                    }
                    else
                    {
                        if (vo.Overlap != 0)
                        {
                            rdr.Close();
                            string insert = "insert into login " +
                            "values('" + vo.Id + "','" + vo.Pw + "','" + vo.Name + "','" + vo.Call + "','" + vo.Du + "')";
                            MySqlCommand comm = new MySqlCommand(insert, conn);
                            comm.ExecuteNonQuery();
                            System.Windows.Forms.MessageBox.Show("가입완료");
                            joins.Close();
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("중복을 누르세요");
                        }
                        
                        
                    }

                    

                    

                }
            }
            catch (Exception ex)
            {

                System.Windows.Forms.MessageBox.Show("연결실패", ex.Message);
                conn.Close();

            }
            finally
            {
                conn.Close();
            }
        }

        public void overlap(VO vo)
        {
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    string select = "select * from login where id = '" + vo.Id + "'";
                    MySqlCommand commm = new MySqlCommand(select, conn);
                    MySqlDataReader rdr = commm.ExecuteReader();
                    if (rdr.Read())
                    {
                        System.Windows.Forms.MessageBox.Show("중복된 아이디");
                        vo.Id = "";
                        
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("사용가능한 아이디");
                        
                    }
                    rdr.Close();

                }
            }
            catch (Exception ex)
            {

                System.Windows.Forms.MessageBox.Show("연결실패", ex.Message);
                

            }
            finally
            {
                conn.Close();
            }
        }

  

    }
}
