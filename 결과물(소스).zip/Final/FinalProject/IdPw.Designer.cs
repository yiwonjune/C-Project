﻿namespace FinalProject
{
    partial class IdPw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnIDfind = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.findName = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnfindPw = new System.Windows.Forms.Button();
            this.findName2 = new System.Windows.Forms.TextBox();
            this.findId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(59, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 50);
            this.label1.TabIndex = 5;
            this.label1.Text = "ID / PW 찾기";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnIDfind);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.findName);
            this.groupBox1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(36, 91);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(290, 122);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ID 찾기";
            // 
            // btnIDfind
            // 
            this.btnIDfind.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnIDfind.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIDfind.ForeColor = System.Drawing.Color.White;
            this.btnIDfind.Location = new System.Drawing.Point(231, 99);
            this.btnIDfind.Name = "btnIDfind";
            this.btnIDfind.Size = new System.Drawing.Size(59, 23);
            this.btnIDfind.TabIndex = 2;
            this.btnIDfind.Text = "찾기";
            this.btnIDfind.UseVisualStyleBackColor = false;
            this.btnIDfind.Click += new System.EventHandler(this.BtnIDfind_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "이름 : ";
            // 
            // findName
            // 
            this.findName.Location = new System.Drawing.Point(117, 51);
            this.findName.Name = "findName";
            this.findName.Size = new System.Drawing.Size(100, 23);
            this.findName.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnfindPw);
            this.groupBox2.Controls.Add(this.findName2);
            this.groupBox2.Controls.Add(this.findId);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(36, 231);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(290, 122);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PW 찾기";
            // 
            // btnfindPw
            // 
            this.btnfindPw.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnfindPw.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnfindPw.ForeColor = System.Drawing.Color.White;
            this.btnfindPw.Location = new System.Drawing.Point(231, 99);
            this.btnfindPw.Name = "btnfindPw";
            this.btnfindPw.Size = new System.Drawing.Size(59, 23);
            this.btnfindPw.TabIndex = 4;
            this.btnfindPw.Text = "찾기";
            this.btnfindPw.UseVisualStyleBackColor = false;
            this.btnfindPw.Click += new System.EventHandler(this.btnfindPw_Click);
            // 
            // findName2
            // 
            this.findName2.Location = new System.Drawing.Point(117, 63);
            this.findName2.Name = "findName2";
            this.findName2.Size = new System.Drawing.Size(100, 23);
            this.findName2.TabIndex = 3;
            // 
            // findId
            // 
            this.findId.Location = new System.Drawing.Point(117, 25);
            this.findId.Name = "findId";
            this.findId.Size = new System.Drawing.Size(100, 23);
            this.findId.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "이름 : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "ID : ";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(112, 368);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(122, 41);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "돌아가기";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // IdPw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(357, 421);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "IdPw";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "아이디/비밀번호 찾기";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.IdPw_FormClosed);
            this.Load += new System.EventHandler(this.IdPw_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox findName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnIDfind;
        private System.Windows.Forms.Button btnfindPw;
        private System.Windows.Forms.TextBox findName2;
        private System.Windows.Forms.TextBox findId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnBack;
    }
}