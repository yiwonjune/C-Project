﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class VO
    {
        string id;
        string pw;
        string name;
        string call;
        string du;
        string carcode;
        string carkind;
        string carname;
        int caryear;
        int carkilo;
        int cardoll;
        int cardeal;
        string dealcode;
        string dealname;
        int dealsu;
        string dealcall;
        string deallist;
        double dealsatis;
        int count = 0;
        int overlap = 0;
        int port;
        string selling = "판매중";
        string consult = "상담";
        
        
        public string de = "딜러";
        public string us = "이용자";
        private object asd;

        public string carTypeStr = "";
        public string carModelStr = "";
        public string carMoneyStr = "";
        public string carYearStr = "";
        public string carKiloStr = "";
        string saveType;
        string saveModel;
        string saveMoney;
        string saveYear;
        string saveKilo;





        public string Id { get => id; set => id = value; }
        public string Pw { get => pw; set => pw = value; }
        public string Carcode { get => carcode; set => carcode = value; }
        public string Carkind { get => carkind; set => carkind = value; }
        public string Carname { get => carname; set => carname = value; }
        public int Caryear { get => caryear; set => caryear = value; }
        public int Carkilo { get => carkilo; set => carkilo = value; }
        public int Cardoll { get => cardoll; set => cardoll = value; }
        public int Cardeal { get => cardeal; set => cardeal = value; }
        public string Dealcode { get => dealcode; set => dealcode = value; }
        public string Dealname { get => dealname; set => dealname = value; }
        public int Dealsu { get => dealsu; set => dealsu = value; }
        public string Dealcall { get => dealcall; set => dealcall = value; }
        public string Deallist { get => deallist; set => deallist = value; }
        public double Dealsatis { get => dealsatis; set => dealsatis = value; }
        public string Name { get => name; set => name = value; }
        public string Call { get => call; set => call = value; }
        public string Du { get => du; set => du = value; }
        public int Count { get => count; set => count = value; }
        public int Overlap { get => overlap; set => overlap = value; }
        public string Selling { get => selling; set => selling = value; }
        public string Consult { get => consult; set => consult = value; }
        public int Port { get => port; set => port = value; }
        public string SaveType { get => saveType; set => saveType = value; }
        public string SaveModel { get => saveModel; set => saveModel = value; }
        public string SaveMoney { get => saveMoney; set => saveMoney = value; }
        public string SaveYear { get => saveYear; set => saveYear = value; }
        public string SaveKilo { get => saveKilo; set => saveKilo = value; }
    }
}
