﻿namespace FinalProject
{
    partial class join
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnJoin = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtJName = new System.Windows.Forms.TextBox();
            this.txtJId = new System.Windows.Forms.TextBox();
            this.txtJPw = new System.Windows.Forms.TextBox();
            this.txtJCall = new System.Windows.Forms.TextBox();
            this.rdUserss = new System.Windows.Forms.RadioButton();
            this.rdDeale = new System.Windows.Forms.RadioButton();
            this.btnDistinct = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnJoin
            // 
            this.btnJoin.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnJoin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnJoin.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnJoin.ForeColor = System.Drawing.Color.White;
            this.btnJoin.Location = new System.Drawing.Point(72, 362);
            this.btnJoin.Name = "btnJoin";
            this.btnJoin.Size = new System.Drawing.Size(86, 39);
            this.btnJoin.TabIndex = 0;
            this.btnJoin.Text = "가입";
            this.btnJoin.UseVisualStyleBackColor = false;
            this.btnJoin.Click += new System.EventHandler(this.btnJoin_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(195, 362);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(86, 39);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "돌아가기";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(65, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 50);
            this.label1.TabIndex = 5;
            this.label1.Text = "회 원 가 입";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(31, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "이름";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(31, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(19, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(31, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "PW";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(31, 293);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Call";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(143, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "회원구분";
            // 
            // txtJName
            // 
            this.txtJName.Location = new System.Drawing.Point(104, 158);
            this.txtJName.Name = "txtJName";
            this.txtJName.Size = new System.Drawing.Size(138, 21);
            this.txtJName.TabIndex = 11;
            // 
            // txtJId
            // 
            this.txtJId.Location = new System.Drawing.Point(104, 200);
            this.txtJId.Name = "txtJId";
            this.txtJId.Size = new System.Drawing.Size(138, 21);
            this.txtJId.TabIndex = 12;
            // 
            // txtJPw
            // 
            this.txtJPw.Location = new System.Drawing.Point(104, 243);
            this.txtJPw.Name = "txtJPw";
            this.txtJPw.Size = new System.Drawing.Size(138, 21);
            this.txtJPw.TabIndex = 13;
            // 
            // txtJCall
            // 
            this.txtJCall.Location = new System.Drawing.Point(104, 290);
            this.txtJCall.Name = "txtJCall";
            this.txtJCall.Size = new System.Drawing.Size(138, 21);
            this.txtJCall.TabIndex = 14;
            // 
            // rdUserss
            // 
            this.rdUserss.AutoSize = true;
            this.rdUserss.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rdUserss.Location = new System.Drawing.Point(104, 116);
            this.rdUserss.Name = "rdUserss";
            this.rdUserss.Size = new System.Drawing.Size(61, 19);
            this.rdUserss.TabIndex = 15;
            this.rdUserss.TabStop = true;
            this.rdUserss.Text = "이용자";
            this.rdUserss.UseVisualStyleBackColor = true;
            // 
            // rdDeale
            // 
            this.rdDeale.AutoSize = true;
            this.rdDeale.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rdDeale.Location = new System.Drawing.Point(186, 116);
            this.rdDeale.Name = "rdDeale";
            this.rdDeale.Size = new System.Drawing.Size(49, 19);
            this.rdDeale.TabIndex = 16;
            this.rdDeale.TabStop = true;
            this.rdDeale.Text = "딜러";
            this.rdDeale.UseVisualStyleBackColor = true;
            // 
            // btnDistinct
            // 
            this.btnDistinct.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnDistinct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDistinct.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.btnDistinct.ForeColor = System.Drawing.Color.White;
            this.btnDistinct.Location = new System.Drawing.Point(263, 192);
            this.btnDistinct.Name = "btnDistinct";
            this.btnDistinct.Size = new System.Drawing.Size(82, 32);
            this.btnDistinct.TabIndex = 17;
            this.btnDistinct.Text = "중복확인";
            this.btnDistinct.UseVisualStyleBackColor = false;
            this.btnDistinct.Click += new System.EventHandler(this.btnDistinct_Click);
            // 
            // join
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(357, 421);
            this.Controls.Add(this.btnDistinct);
            this.Controls.Add(this.rdDeale);
            this.Controls.Add(this.rdUserss);
            this.Controls.Add(this.txtJCall);
            this.Controls.Add(this.txtJPw);
            this.Controls.Add(this.txtJId);
            this.Controls.Add(this.txtJName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnJoin);
            this.Name = "join";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "회원가입";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.join_FormClosed);
            this.Load += new System.EventHandler(this.join_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnJoin;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtJName;
        private System.Windows.Forms.TextBox txtJId;
        private System.Windows.Forms.TextBox txtJPw;
        private System.Windows.Forms.TextBox txtJCall;
        private System.Windows.Forms.RadioButton rdUserss;
        private System.Windows.Forms.RadioButton rdDeale;
        private System.Windows.Forms.Button btnDistinct;
    }
}