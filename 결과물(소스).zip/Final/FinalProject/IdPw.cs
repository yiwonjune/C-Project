﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class IdPw : Form
    {
        DAO dao = new DAO();
        LoginForm login;
        VO vo = new VO();

        public IdPw()
        {
            
            
        }

        public IdPw(LoginForm loginForm)
        {
            InitializeComponent();
            login = loginForm;

            login.Visible = false;

        }

        private void IdPw_Load(object sender, EventArgs e)
        {

        }

        private void BtnIDfind_Click(object sender, EventArgs e)
        {
            if (findName.Text != "")
            {
                vo.Name = findName.Text;
                dao.findID(vo);
                
            }
            
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {

            Close();
            
            

        }

        private void IdPw_FormClosed(object sender, FormClosedEventArgs e)
        {
            login.Visible = true;
        }

        private void btnfindPw_Click(object sender, EventArgs e)
        {
            if (findId.Text != "" && findName2.Text != "")
            {
                vo.Id = findId.Text;
                vo.Name = findName2.Text;
                

                dao.findPW(vo);
            }
        }
    }
}
