﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class CClient : Form
    {

        TcpListener Server;
        TcpClient Client2;
        StreamReader Reader;
        StreamWriter Writer;
        NetworkStream stream;
        Thread ReceiveThread;
        VO vo = new VO();
        int port = 8011; // 포트
        SServer sv;
        bool Connected;
        private delegate void AddTextDelegate(string strText); // 크로스 쓰레드 호출
        public CClient(SServer server)
        {
            InitializeComponent();
            vo.Count = 0;
            sv = server;
        }

        private void Client_Load(object sender, EventArgs e)
        {
            String IP = "203.232.133.33"; // 접속 할 서버 아이피를 입력
            
            
            Client2 = new TcpClient();
            Client2.Connect(IP, port);
            stream = Client2.GetStream();
            Connected = true;
            textBox1.AppendText("상담원과 연결" + "\r\n");
            Reader = new StreamReader(stream);
            Writer = new StreamWriter(stream);
            ReceiveThread = new Thread(new ThreadStart(Receive));
            ReceiveThread.Start();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Tray tray = new Tray(sv);
            if (txtMsg.Text != "")
            {
                if (vo.Count == 0)
                {
                    tray.MsgText = this.txtMsg.Text;
                    tray.ShowDialog();
                }

                textBox1.AppendText("나 : " + txtMsg.Text + "\r\n");
                Writer.WriteLine(txtMsg.Text); // 보내버리기
                Writer.Flush();
                txtMsg.Clear();
            }

            vo.Count = 1;
            
            
        }
        

        private void Receive()
        {
            AddTextDelegate AddText = new AddTextDelegate(textBox1.AppendText);

            while (Connected)

            {

                Thread.Sleep(1);

                if (stream.CanRead)
                {
                    string tempStr = Reader.ReadLine();
                    if (tempStr.Length > 0)
                    {
                        Invoke(AddText, "딜러 : " + tempStr + "\r\n");
                    }
                }
            }

        }

        private void CClient_FormClosed(object sender, FormClosedEventArgs e)
        {
            

        }

        private void Form1_Closing(object sender, FormClosingEventArgs e)
        {
            Connected = false;

            if (Reader != null) Reader.Close();

            if (Writer != null) Writer.Close();

            if (Server != null) Server.Stop();

            if (Client2 != null) Client2.Close();

            if (ReceiveThread != null) ReceiveThread.Abort();

            port++;
        }
    }
}
