﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace FinalProject
{
    public partial class Buyer : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        LoginForm login;
        VO vo = new VO();
        DataSet DS = new DataSet();


        static string connStr = string.Format("server=localhost;" +
                "user=root;" +
                "password=apmsetup;" +
                "database=Usedcar;" +
                "CharSet = utf8;");

        public Buyer(LoginForm loginForm)
        {
            InitializeComponent();
            login = loginForm;
            login.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Buyer_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection(connStr);

            if (this.OpenConnection() == true)
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car", connection);
                
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
                
            }

            
        }

        private void CarInform_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            DataTable data = ((DataTable)CarInform.DataSource).GetChanges();
            if (data != null)
            {
                MySqlCommandBuilder mcb = new MySqlCommandBuilder(mySqlDataAdapter);
                mySqlDataAdapter.UpdateCommand = mcb.GetUpdateCommand();
                mySqlDataAdapter.Update(data);
                ((DataTable)CarInform.DataSource).AcceptChanges();
            }
        }

        private bool OpenConnection() //DB연결 
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection() // DB닫기
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void CarInform_CellClick(object sender, DataGridViewCellEventArgs e) //DataGridView 버튼 이벤트 구현 상담 연결 
        {
            /*for (int i = 0; i < DS.Tables[0].ToString().Length; i++)
            {
                if (CarInform.Rows[i].Cells[8])
                {

                }
                CarInform.Rows[i].Cells[8] = new DataGridViewButtonCell();
            }*/
            


            
        }

        private void button1_Click(object sender, EventArgs e) // 콤보 박스에서 차량종류 선택 후 버튼 클릭 이벤트 
        {
            mySqlDataAdapter = new MySqlDataAdapter("select * from car where 차량종류 = '" + vo.SaveType + "'", connection);
            DataSet DS = new DataSet();
            mySqlDataAdapter.Fill(DS, "car");
            CarInform.DataSource = DS.Tables[0];
            this.CloseConnection();
            cbType.SelectedItem = null;
        }

        private void button4_Click(object sender, EventArgs e) // 콤보 박스에서 모델 선택 후 버튼 클릭 이벤트
        {
            mySqlDataAdapter = new MySqlDataAdapter("select * from car where 모델 = '" + vo.SaveModel + "'", connection);
            DataSet DS = new DataSet();
            mySqlDataAdapter.Fill(DS, "car");
            CarInform.DataSource = DS.Tables[0];
            this.CloseConnection();
            cbModel.SelectedItem = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mySqlDataAdapter = new MySqlDataAdapter("select * from car where 딜러 = '" + this.txtDealer.Text + "'", connection);
            DataSet DS = new DataSet();
            mySqlDataAdapter.Fill(DS, "car");
            CarInform.DataSource = DS.Tables[0];
            this.CloseConnection();
            txtDealer.Text = "";

        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(this.cbType.Text != "")
            {
                vo.SaveType = vo.carTypeStr + this.cbType.Text;
            }
        }

        private void cbModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cbModel.Text != "")
            {
                vo.SaveModel = vo.carModelStr + this.cbModel.Text;
            }
        }

        private void cbmoney_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cbmoney.Text != "")
            {
                vo.SaveMoney = vo.carMoneyStr + this.cbmoney.Text;
            }
        }

        private void cbYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cbYear.Text != "")
            {
                vo.SaveYear = vo.carYearStr + this.cbYear.Text;
            }
        }

        private void cbKilo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cbKilo.Text != "")
            {
                vo.SaveKilo = vo.carKiloStr + this.cbKilo.Text;
            }
        }

        private void button5_Click(object sender, EventArgs e) // 콤보 박스에서 연식 선택 후 버튼 클릭 이벤트
        {
            mySqlDataAdapter = new MySqlDataAdapter("select * from car where 연식 = '" + vo.SaveYear + "'", connection);
            DataSet DS = new DataSet();
            mySqlDataAdapter.Fill(DS, "car");
            CarInform.DataSource = DS.Tables[0];
            this.CloseConnection();
            cbYear.SelectedItem = null;
        }

        private void button6_Click(object sender, EventArgs e) //콤보 박스에서 킬로수 선택 후 버튼 클릭 이벤트
        {
            if (vo.SaveKilo == "10000") // 콤보 박스에서 선택한 것이 10000일때 Sql쿼리 조건검색 발생
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 10000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "20000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 20000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "30000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 30000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "40000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 40000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "50000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 50000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "60000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 60000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "70000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 70000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "80000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 80000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "90000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 90000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveKilo == "100000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 주행거리 >= 100000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }

            cbKilo.SelectedItem = null;
        }

        private void button3_Click(object sender, EventArgs e) //콤보 박스에서 금액 선택 후 버튼 클릭 이벤트
        {
            if (vo.SaveMoney == "100") // 콤보 박스에서 선택한 것이 10000일때 Sql쿼리 조건검색 발생
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 100", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "500")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 500", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "1000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 1000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "1500")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 1500", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "2000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 2000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "2500")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 2500", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "3000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 3000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "3500")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 3500", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
            else if (vo.SaveMoney == "4000")
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car where 금액 >= 4000", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
            }

            cbmoney.SelectedItem = null;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            login.Show();
            this.Close();
        }

        private void btnSell_Click(object sender, EventArgs e)
        {

            mySqlDataAdapter = new MySqlDataAdapter("update car set 판매여부 = '판매불가' where 차량코드 = '" + this.CarInform.Rows[this.CarInform.CurrentCellAddress.Y].Cells[0].Value + "'", connection);




                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();
                CarInform.Columns.Clear();



            connection = new MySqlConnection(connStr);

            if (this.OpenConnection() == true)
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from car", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS, "car");
                CarInform.DataSource = DS.Tables[0];
                this.CloseConnection();

            }







        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            CarInform.Columns.Clear();
            mySqlDataAdapter = new MySqlDataAdapter("select * from car", connection);
            DataSet DS = new DataSet();
            mySqlDataAdapter.Fill(DS, "car");
            CarInform.DataSource = DS.Tables[0];
            this.CloseConnection();
        }

        private void CarInform_SelectionChanged(object sender, EventArgs e)
        {
           
        }

        private void btnCoun_Click(object sender, EventArgs e)
        {
            SServer sv = new SServer();

            sv.Show();
            sv.Visible = false;

            CClient cl = new CClient(sv);
            cl.Show();
        }
    }
}
