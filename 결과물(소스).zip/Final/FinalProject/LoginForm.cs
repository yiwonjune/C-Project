﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Threading;

namespace FinalProject
{
    public partial class LoginForm : Form
    {
        

        DAO dao = new DAO();
        VO vo = new VO();
        

        public LoginForm()
        {
            InitializeComponent();
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            vo.Id = txtID.Text;
            vo.Pw = txtPW.Text;
            if (rdDeal.Checked)
            {
                vo.Du = "딜러";
            }
            else if (rdUser.Checked)
            {
                vo.Du = "이용자";
            }

           
                if (txtID.Text != "" && txtPW.Text != "")
                {
                    dao.idpwCheck(vo, this);
                }

            txtID.Text = null;
            txtPW.Text = null;
                

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {
            IdPw ip = new IdPw(this);
            ip.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            join join = new join(this);
            join.Show();
        }

        private void txtPW_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                e.Handled = true;
                btnLogin_Click(sender, e);
            }
        }

        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }
    }
}
