﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class join : Form
    {
        DAO dao = new DAO();
        LoginForm login;
        VO vo = new VO();

        public join(LoginForm loginForm)
        {
            InitializeComponent();
            login = loginForm;
            login.Visible = false;
        }

        private void join_Load(object sender, EventArgs e)
        {
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void join_FormClosed(object sender, FormClosedEventArgs e)
        {
            login.Visible = true;
        }

        private void btnJoin_Click(object sender, EventArgs e)
        {
            if (txtJName.Text != "" && txtJId.Text != "" && txtJPw.Text != "" && txtJCall.Text != "")
            {
                vo.Name = txtJName.Text;
                vo.Id = txtJId.Text;
                vo.Pw = txtJPw.Text;
                vo.Call = txtJCall.Text;
                if (rdDeale.Checked)
                {
                    vo.Du = vo.de;
                }
                else if (rdUserss.Checked)
                {
                    vo.Du = vo.us;
                }

                dao.join(vo, this);
            }
            else
            {
                MessageBox.Show("전부 입력하세요.");
            }

        }

        private void btnDistinct_Click(object sender, EventArgs e)
        {
            if (txtJId.Text != "")
            {
                vo.Id = txtJId.Text;
                vo.Overlap = 1;

                dao.overlap(vo);

            }
            txtJId.Text = vo.Id;
        }

        
    }
}
