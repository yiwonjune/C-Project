﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class SServer : Form
    {
        OpenFileDialog file = new OpenFileDialog();
        
        TcpListener Server;
        TcpClient Client;
        StreamReader Reader;
        StreamWriter Writer;
        NetworkStream stream; // 네트워크 스트림 연결
        Thread ReceiveThread;
        int port = 8011; // 서버 포트

        bool Connected;
        private delegate void AddTextDelegate(string strText); // 크로스 쓰레드 호출
        public SServer()
        {
            InitializeComponent();
            Thread ListenThread = new Thread(new ThreadStart(Listen)); // 서버 시작
            ListenThread.Start();

        }

        private void SServer_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.AppendText("나 : " + textBox4.Text + "\r\n"); // 화면에 출력
            Writer.WriteLine(textBox4.Text); // 보내버리기
            Writer.Flush();
            textBox4.Clear();
        }
        
        private void Listen()
        {
            
            AddTextDelegate AddText = new AddTextDelegate(textBox3.AppendText);
            IPAddress addr = new IPAddress(0); // 서버 ip

            
            Server = new TcpListener(addr, port);
            Server.Start(); // 서버 시작

            Invoke(AddText, " " + "\r\n");
            Client = Server.AcceptTcpClient(); // 클라이언트 연결 수락
            Connected = true;
            Invoke(AddText, "고객과 연결" + "\r\n");
            stream = Client.GetStream(); // 클라이언트 스트림 값 받아오기
            Reader = new StreamReader(stream);
            Writer = new StreamWriter(stream);
            ReceiveThread = new Thread(new ThreadStart(Receive)); // 값을 받기 위한 쓰레드
            ReceiveThread.Start();

        }
        private void Receive()
        {
            AddTextDelegate AddText = new AddTextDelegate(textBox3.AppendText);
            while (Connected)
            {
                Thread.Sleep(1);
                if (stream.CanRead)
                {
                    string tempStr = Reader.ReadLine();
                    if (tempStr.Length > 0)
                    {
                        Invoke(AddText, "고객 : " + tempStr + "\r\n");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string dir = "";
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "텍스트 파일|*.txt";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                dir = sfd.FileName;
                FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine(textBox3.Text);
                sw.Flush();
                sw.Close();
                fs.Close();
                this.Close();
            }


        }

        private void SServer_Shown(object sender, EventArgs e)
        {
            
        }

        private void SServer_FormClosed(object sender, FormClosedEventArgs e)
        {
            Server.Server.Close(0);
            Server.Stop();
            port++;
        }

        private void Form1_Closing(object sender, FormClosingEventArgs e)
        {

            Connected = false;
            if (Reader != null) Reader.Close();

            if (Writer != null) Writer.Close();

            

            if (Client != null) Client.Close();

            if (ReceiveThread != null) ReceiveThread.Abort();


            
        }
    }
}
