-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 19-07-31 23:30 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `usedcar`
--
CREATE DATABASE `usedcar` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `usedcar`;

-- --------------------------------------------------------

--
-- 테이블 구조 `car`
--

CREATE TABLE IF NOT EXISTS `car` (
  `차량코드` varchar(20) NOT NULL,
  `차량종류` varchar(20) NOT NULL,
  `모델` varchar(20) NOT NULL,
  `연식` int(20) NOT NULL,
  `주행거리` int(30) NOT NULL,
  `금액` int(30) NOT NULL,
  `딜러` varchar(20) NOT NULL,
  `판매여부` varchar(20) NOT NULL,
  `상담` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `car`
--

INSERT INTO `car` (`차량코드`, `차량종류`, `모델`, `연식`, `주행거리`, `금액`, `딜러`, `판매여부`, `상담`) VALUES
('H001', '소나타', '소나타 뉴 2018', 2011, 2000, 2000, '임병돈', '판매중', '상담'),
('G002', '그랜져', '그랜져', 2011, 20000, 1000, '김종영', '판매중', '상담'),
('H003', '소나타', '소나타 뉴 2018', 2018, 2000, 2000, '임병돈', '판매불가', '상담'),
('H002', '소나타', '소나타 뉴 2018', 2018, 2000, 2000, '임병돈', '판매불가', '상담'),
('H001', '소나타', '소나타 뉴 2018', 2011, 2000, 2000, '임병돈', '판매중', '상담'),
('G002', '그랜져', '그랜져', 2011, 20000, 1000, '김종영', '판매중', '상담'),
('K000', 'K7', 'K7', 2007, 1000, 3000, '이원준', '판매중', '상담'),
('H005', '그랜저', '그랜저 2015', 2011, 4000, 100, '임병돈', '판매중', '상담'),
('K001', 'K7', 'K7 뉴', 2019, 100, 30000, '이원준', '판매중', '상담'),
('G004', '그랜져', '그랜져 뉴', 2014, 20000, 10000, '김종영', '판매불가', '상담');

-- --------------------------------------------------------

--
-- 테이블 구조 `dealerr`
--

CREATE TABLE IF NOT EXISTS `dealerr` (
  `dealcode` varchar(20) NOT NULL,
  `dealname` varchar(20) NOT NULL,
  `dealsu` int(10) NOT NULL,
  `dealcall` varchar(20) DEFAULT NULL,
  `deallist` varchar(20) DEFAULT NULL,
  `dealsatis` double DEFAULT NULL,
  PRIMARY KEY (`dealcode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `dealerr`
--

INSERT INTO `dealerr` (`dealcode`, `dealname`, `dealsu`, `dealcall`, `deallist`, `dealsatis`) VALUES
('A001', '김종영', 12, '01063300547', NULL, 4.5);

-- --------------------------------------------------------

--
-- 테이블 구조 `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` varchar(20) NOT NULL,
  `pw` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `call` varchar(20) NOT NULL,
  `du` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `login`
--

INSERT INTO `login` (`id`, `pw`, `name`, `call`, `du`) VALUES
('powerthd89', 'asdf', '김종영', '01063300547', '딜러'),
('username', 'asd', '임병돈', '01032221234', '이용자'),
('sdfsdf', '143123', '나쁜놈', '01033333333', '딜러'),
('vxczvxcvxzcv', '12313123', '이원준', '01033333333', '딜러'),
('xvczxmn', '12321321', '나성일', '01063300211', '이용자'),
('sdfvcxv', '1243142', '임씨', '0103331121', '딜러'),
('bxbzb', 'sdaf12', 'park', '01032322222', '딜러'),
('ffff', '1111', '원준', '1111', '이용자'),
('dddd', '2222', '아아', '4444', '딜러'),
('final', 'asd', '이인인', '01063300547', '이용자'),
('final2', 'asd', '이이잉', '0180232116', '딜러');
